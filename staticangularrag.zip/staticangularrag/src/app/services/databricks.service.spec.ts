import { TestBed } from '@angular/core/testing';

import { DatabricksService } from './databricks.service';

describe('DatabricksService', () => {
  let service: DatabricksService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DatabricksService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
