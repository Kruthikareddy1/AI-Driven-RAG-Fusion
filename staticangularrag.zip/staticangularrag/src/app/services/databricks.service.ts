// import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// import { Observable } from 'rxjs';

// @Injectable({
//   providedIn: 'root'
// })
// export class DatabricksService {
//   private baseApiUrl = 'https://adb-1620865038680305.5.azuredatabricks.net/api/2.1/jobs/run-now'; // Correct base URL

//   constructor(private http: HttpClient) { }

//   // Trigger the job and get run_id
//   triggerJob(jobId: number, userQuery: string): Observable<any> {
//     const url = `${this.baseApiUrl}/run-now`; // Correct endpoint
//     const payload = {
//       job_id: jobId,
//       notebook_params: { user_query: userQuery }
//     };

//     const headers = {
//       Authorization: `Bearer dapice49002ac9e823d92f23bd5cf2c3e1c6-3`, // Replace with your actual token
//       'Content-Type': 'application/json'
//     };

//     return this.http.post(url, payload, { headers });
//   }

//   // Get the job status and details using run_id
//   getJobStatus(runId: string): Observable<any> {
//     const url = `${this.baseApiUrl}/runs/get?run_id=${runId}`;

//     const headers = {
//       Authorization: `Bearer dapice49002ac9e823d92f23bd5cf2c3e1c6-3`, // Replace with your actual token
//       'Content-Type': 'application/json'
//     };

//     return this.http.get(url, { headers });
//   }

//   // Get the notebook output using run_id
//   getNotebookOutput(runId: string): Observable<any> {
//     const url = `${this.baseApiUrl}/runs/get-output?run_id=${runId}`;

//     const headers = {
//       Authorization: `Bearer dapice49002ac9e823d92f23bd5cf2c3e1c6-3`, // Replace with your actual token
//       'Content-Type': 'application/json'
//     };

//     return this.http.get(url, { headers });
//   }
// }

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DatabricksService {
  private baseApiUrl = 'https://adb-1620865038680305.5.azuredatabricks.net/api/2.1/jobs/run-now'; // Updated base URL

  constructor(private http: HttpClient) { }

  // Trigger the job and get run_id
  triggerJob(jobId: number, userQuery: string, fusionType: string): Observable<any> {
    const url = `${this.baseApiUrl}/run-now`; // Correct endpoint
    const payload = {
      job_id: jobId,
      notebook_params: { user_query: userQuery, fusion_type: fusionType } // Include fusion type
    };

    const headers = {
      Authorization: `Bearer dapice49002ac9e823d92f23bd5cf2c3e1c6-3`, // Replace with your actual token
      'Content-Type': 'application/json'
    };

    return this.http.post(url, payload, { headers });
  }

  // Get the job status and details using run_id
  getJobStatus(runId: string): Observable<any> {
    const url = `${this.baseApiUrl}/runs/get?run_id=${runId}`;

    const headers = {
      Authorization: `Bearer dapice49002ac9e823d92f23bd5cf2c3e1c6-3`, // Replace with your actual token
      'Content-Type': 'application/json'
    };

    return this.http.get(url, { headers });
  }

  // Get the notebook output using run_id
  getNotebookOutput(runId: string): Observable<any> {
    const url = `${this.baseApiUrl}/runs/get-output?run_id=${runId}`;

    const headers = {
      Authorization: `Bearer dapice49002ac9e823d92f23bd5cf2c3e1c6-3`, // Replace with your actual token
      'Content-Type': 'application/json'
    };

    return this.http.get(url, { headers });
  }
}
