

// import { CommonModule } from '@angular/common';
// import { Component, ViewChild, ElementRef, ChangeDetectorRef } from '@angular/core';
// import { Router } from '@angular/router';
// import { DatabricksService } from '../services/databricks.service'; // Adjust path as necessary
// import { FormsModule } from '@angular/forms';
// import axios from 'axios';

// @Component({
//   standalone: true,
//   selector: 'app-dashboard',
//   templateUrl: './dashboard.component.html',
//   styleUrls: ['./dashboard.component.css'],
//   imports: [CommonModule, FormsModule]
// })
// export class DashboardComponent {
//   query: string = '';
//   messages: { type: string; text: string }[] = [];
//   userMessage: string = '';
//   selectedFusionType: string = ''; // Added property for dropdown selection
//   kValue: number = 1; // Default K value
//   // preranked_docs: any[] = []; / Add logic here to populate preranked_docs
//   @ViewChild('searchInput') searchInput!: ElementRef<HTMLInputElement>;

//   loading: boolean = false; // Add loading property

//   constructor(
//     private router: Router,
//     private databricksService: DatabricksService,
//     private cdr: ChangeDetectorRef
//   ) {}

//   navigateToValidation(): void {
//     this.router.navigate(['/validation']);
//   }

//   focusSearchInput(): void {
//     this.searchInput.nativeElement.focus();
//   }

//   async sendMessage() {
   
    



//     this.messages.push({ type: 'user', text: this.userMessage });
    
//     let fusionType = 'score';  // Default to score fusion
//     let k = this.kValue || 1;  // Default K value if not entered
//     if (this.selectedFusionType === 'merge' && k > 1) {
//       fusionType = 'merge'; // Use 'merge fusion' if K > 1
//     } else if (k === 1) {
//       fusionType = 'score'; // Use 'score fusion' if K = 1
//     }

//     try {
//       const response = await axios.post('http://localhost:5000/retrieve', {
//         query: this.userMessage,
//         top_k: k,
//         get_reranked: true
//       });

//       // Only display the summary from the response
//       this.messages.push({ type: 'bot', text: response.data.summary });
//       this.query = ''; // Clear input after sending query
//     } catch (error) {
//       console.error('Error sending query:', error);
//     } finally {
//       this.userMessage = ''; 
//       this.loading = false; // Stop loading
//     }
//   }

//   // Function to execute Databricks job using the user's query and selected fusion type
//   executeDatabricksJob(userQuery: string, fusionType: string) {
//     const jobId = 70792116727426;  // Ensure this is a valid job ID

//     this.databricksService.triggerJob(jobId, userQuery, fusionType).subscribe(
//       (response) => {
//         const runId = response.run_id;
//         // this.pollJobStatus(runId);
//       },
//       (error) => {
//         console.error('Error triggering job:', error);
//         this.messages.push({ type: 'bot', text: 'Error while processing your query. Please try again.' });
//       }
//     );
//   }

 

//   getNotebookOutput(runId: string) {
//     this.databricksService.getNotebookOutput(runId).subscribe(
//       (outputResponse) => {
//         const notebookOutput = outputResponse.notebook_output.result;
//         this.messages.push({ type: 'bot', text: notebookOutput });
//       },
//       (error) => {
//         console.error('Error fetching notebook output:', error);
//         this.messages.push({ type: 'bot', text: 'Failed to retrieve the output. Please try again.' });
//       }
//     );
//   }
// }


import { CommonModule } from '@angular/common';
import { Component, ViewChild, ElementRef, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { DatabricksService } from '../services/databricks.service'; // Adjust path as necessary
import { FormsModule } from '@angular/forms';
import axios from 'axios';

@Component({
  standalone: true,
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  imports: [CommonModule, FormsModule]
})
export class DashboardComponent {
  query: string = '';
  messages: { type: string; text: string }[] = [];
  userMessage: string = '';
  selectedFusionType: string = ''; // Added property for dropdown selection
  kValue: number = 1; // Default K value
  // preranked_docs: any[] = []; / Add logic here to populate preranked_docs
  @ViewChild('searchInput') searchInput!: ElementRef<HTMLInputElement>;

  loading: boolean = false; // Add loading property

  constructor(
    private router: Router,
    private databricksService: DatabricksService,
    private cdr: ChangeDetectorRef
  ) {}

  navigateToValidation(): void {
    this.router.navigate(['/validation']);
  }

  focusSearchInput(): void {
    this.searchInput.nativeElement.focus();
  }

  async sendMessage() {
    if (!this.userMessage || this.loading) {
      return; // Prevent sending if the query is empty or a request is already processing
    }

    // Set loading state to true to prevent further queries
    this.loading = true;
    



    this.messages.push({ type: 'user', text: this.userMessage });
    
    let fusionType = 'score';  // Default to score fusion
    let k = this.kValue || 1;  // Default K value if not entered
    if (this.selectedFusionType === 'merge' && k > 1) {
      fusionType = 'merge'; // Use 'merge fusion' if K > 1
    } else if (k === 1) {
      fusionType = 'score'; // Use 'score fusion' if K = 1
    }

    try {
      const response = await axios.post('http://localhost:5000/retrieve', {
        query: this.userMessage,
        top_k: k,
        get_reranked: true
      });

      // Only display the summary from the response
      this.messages.push({ type: 'bot', text: response.data.summary });
      this.query = ''; // Clear input after sending query
    } catch (error) {
      console.error('Error sending query:', error);
      this.messages.push({ type: 'bot', text: 'Error while processing your query. Please try again.' });
    } finally {
      this.userMessage = ''; 
      this.loading = false; // Stop loading
    }
  }

  // Function to execute Databricks job using the user's query and selected fusion type
  executeDatabricksJob(userQuery: string, fusionType: string) {
    const jobId = 70792116727426;  // Ensure this is a valid job ID
    this.loading = true; // Set loading to true while the job is executing
    this.databricksService.triggerJob(jobId, userQuery, fusionType).subscribe(
      (response) => {
        const runId = response.run_id;
        // this.pollJobStatus(runId);
      },
      (error) => {
        console.error('Error triggering job:', error);
        this.messages.push({ type: 'bot', text: 'Error while processing your query. Please try again.' });
        this.loading = false; // Reset loading on error
      }
    );
  }

 

  getNotebookOutput(runId: string) {
    if (this.loading) {
      return; // Prevent fetching output while a job is still running
    }
    this.databricksService.getNotebookOutput(runId).subscribe(
      (outputResponse) => {
        const notebookOutput = outputResponse.notebook_output.result;
        this.messages.push({ type: 'bot', text: notebookOutput });
        this.loading = false; // Reset loading once output is fetched
      },
      (error) => {
        console.error('Error fetching notebook output:', error);
        this.messages.push({ type: 'bot', text: 'Failed to retrieve the output. Please try again.' });
        this.loading = false; // Reset loading on error
      }
    );
  }
}
